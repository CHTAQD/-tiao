var convert = require('./convert'),
    func = convert('findLastFrom', require('../findLast'));

func.placeholder = require('./placeholder');
module.exports = func;
