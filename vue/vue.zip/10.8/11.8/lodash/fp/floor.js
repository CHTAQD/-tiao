var convert = require('./convert'),
    func = convert('floor', require('../floor'));

func.placeholder = require('./placeholder');
module.exports = func;
