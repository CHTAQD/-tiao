<?php
echo '你搜索的内容是:'.$_GET['word'];