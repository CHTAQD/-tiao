<?php
echo '你搜索的是'.$_GET['word'];