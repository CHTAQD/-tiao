var convert = require('./convert'),
    func = convert('map', require('../map'));

func.placeholder = require('./placeholder');
module.exports = func;
