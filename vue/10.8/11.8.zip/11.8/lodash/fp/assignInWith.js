var convert = require('./convert'),
    func = convert('assignInWith', require('../assignInWith'));

func.placeholder = require('./placeholder');
module.exports = func;
